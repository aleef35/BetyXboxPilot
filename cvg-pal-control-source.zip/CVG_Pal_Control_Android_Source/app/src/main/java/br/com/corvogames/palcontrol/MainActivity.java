package br.com.corvogames.palcontrol;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Control for one explicitly verified possession; no gamepad promises, no background native attack loop. */
public final class MainActivity extends Activity {
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private volatile boolean busy=false;
    private volatile boolean foreground=false;
    private volatile String key=null;
    private JSONObject current=null;
    private int nextSequence=1;
    private long lastAttackAt=0L;
    private TextView palName, skillLabel, status, details;
    private EditText keyField;
    private Button connect, refresh, arm, attack, check, returnHuman;
    private final Runnable poll=new Runnable(){ public void run(){ if(foreground){ refreshState(false); ui.postDelayed(this,5000); } } };

    private int dp(float v){ return (int)(getResources().getDisplayMetrics().density*v+0.5f); }
    private TextView text(String value,int size,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(Color.rgb(22,29,42));t.setPadding(0,dp(7),0,dp(7));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout panel(){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18),dp(14),dp(18),dp(14));
        p.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams margins=new LinearLayout.LayoutParams(-1,-2);
        margins.setMargins(0,0,0,dp(12));p.setLayoutParams(margins);return p;
    }
    private Button button(String label){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(16);b.setMinHeight(dp(56));return b;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(15,23,42));
        getWindow().setNavigationBarColor(Color.rgb(15,23,42));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(Color.rgb(239,243,249));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(20),dp(16),dp(20));sc.addView(root);
        TextView title=text("CVG  •  PAL CONTROL",24,true);title.setTextColor(Color.rgb(30,49,91));root.addView(title);
        root.addView(text("Xbox + Android  |  GameGrid 00000052",13,false));
        LinearLayout auth=panel();root.addView(auth);
        auth.addView(text("Chave da API GameGrid",15,true));
        keyField=new EditText(this);keyField.setTextSize(13);
        keyField.setSingleLine(true);keyField.setHint("gsk_… (não compartilhe)");
        keyField.setInputType(129);
        auth.addView(keyField,new LinearLayout.LayoutParams(-1,dp(52)));
        connect=button("Conectar");auth.addView(connect);
        connect.setOnClickListener(v->connect());
        LinearLayout palPanel=panel();root.addView(palPanel);
        palPanel.addView(text("PAL POSSUÍDO",12,true));
        palName=text("Nenhuma possessão confirmada",24,true);palPanel.addView(palName);
        skillLabel=text("Golpe: —",15,false);palPanel.addView(skillLabel);
        details=text("Aguardando estado do mod CVG",12,false);palPanel.addView(details);
        refresh=button("Atualizar nome do Pal");palPanel.addView(refresh);
        refresh.setOnClickListener(v->refreshState(true));
        LinearLayout actions=panel();root.addView(actions);
        actions.addView(text("CONTROLE DE ATAQUE",14,true));
        check=button("Verificar golpe (sem disparar)");actions.addView(check);
        check.setOnClickListener(v->send("MOBILECHECK",false));
        arm=button("Armar ataque experimental");actions.addView(arm);
        arm.setOnClickListener(v->confirmArm());
        attack=button("ATACAR COM O PAL");actions.addView(attack);
        attack.setOnClickListener(v->send("MOBILEATTACK",true));
        returnHuman=button("Retornar ao humano");actions.addView(returnHuman);
        returnHuman.setOnClickListener(v->send("MOBILERETURN",false));
        status=text("Sem conexão",14,false);root.addView(status);
        TextView warning=text("AVISO: golpes PlayAction são experimentais e podem derrubar o servidor. Testar somente no clone com backup. Este aplicativo não abre o chat do Xbox.",12,false);
        warning.setTextColor(Color.rgb(145,60,39));root.addView(warning);
        updateButtons();
        setContentView(sc);
        try { key=SecureKeyStore.load(this);if(key!=null)keyField.setText("•••• chave salva ••••"); }
        catch(Exception ignored) {key=null;}
        if(key!=null) refreshState(true);
    }
    private void connect(){
        String raw=keyField.getText().toString().trim();
        if(raw.startsWith("••••") && key!=null) raw=key;
        final String candidate=raw;
        runNetwork("Autenticando…",()->{
            GameGridFiles api=new GameGridFiles(candidate);
            api.checkKey();
            SecureKeyStore.save(this,candidate);
            ui.post(()->{key=candidate;keyField.setText("•••• chave salva ••••");setStatus("Chave validada. Consultando Pal…");refreshState(true);});
        });
    }
    private void setStatus(String message){ status.setText(message); }
    private void runNetwork(String message,Task task){
        if(busy) return;
        busy=true;setStatus(message);updateButtons();
        io.execute(()->{
            try {task.run();}
            catch(Exception e){String error=e.getMessage()==null?"Falha desconhecida":e.getMessage();
                ui.post(()->setStatus("Falha: "+error));}
            finally {ui.post(()->{busy=false;updateButtons();});}
        });
    }
    interface Task {void run() throws Exception;}
    private void refreshState(boolean userInitiated){
        final String token=key;
        if(token==null) { if(userInitiated)setStatus("Conecte sua chave primeiro.");return; }
        runNetwork("Lendo estado do servidor…",()->{
            JSONObject state=new GameGridFiles(token).getPalState();
            long age=Math.abs(System.currentTimeMillis()/1000L - state.optLong("updated_unix",0));
            if(age>45)throw new IllegalStateException("Estado antigo do mod ("+age+" s). Não habilitar ataque.");
            ui.post(()->{
                current=state;
                long remoteSeq=state.optLong("last_sequence",0);
                SharedPreferences pref=getPreferences(MODE_PRIVATE);
                int persisted=pref.getInt("local_seq",1);
                if(remoteSeq>=99999998) {nextSequence=99999999;} else {
                    nextSequence=(int)Math.max(1,Math.max(remoteSeq+1,persisted));
                }
                if(!state.optBoolean("active",false)){
                    palName.setText("Nenhuma possessão confirmada");skillLabel.setText("Golpe: —");
                    details.setText("Inicie a possessão no Xbox.");
                }else{
                    palName.setText(state.optString("pal_name","Pal desconhecido"));
                    skillLabel.setText("Golpe: "+state.optString("skill_name","não identificado"));
                    details.setText("Classe: "+state.optString("pal_class","")
                        +"  |  ID: "+state.optInt("waza_id",0)
                        +"  |  Recarga: "+state.optInt("cooldown_seconds",8)+"s");
                }
                setStatus("Mod: "+state.optString("last_result","estado recebido"));
                updateButtons();
            });
        });
    }
    private boolean eligible(boolean needsArmed){
        if(current==null || key==null) return false;
        if(!current.optBoolean("active",false) || !current.optBoolean("attack_supported",false)) return false;
        String session=current.optString("session","");
        if(!session.matches("[0-9]{10,20}"))return false;
        long age=Math.abs(System.currentTimeMillis()/1000L-current.optLong("updated_unix",0));
        if(age>45)return false;
        return !needsArmed || current.optBoolean("armed",false);
    }
    private void updateButtons(){
        boolean active=!busy&&eligible(false);
        if(refresh!=null)refresh.setEnabled(!busy&&key!=null);
        if(connect!=null)connect.setEnabled(!busy);
        if(check!=null)check.setEnabled(active);
        if(arm!=null){arm.setEnabled(active);arm.setText(current!=null&&current.optBoolean("armed",false)?"Desarmar ataques":"Armar ataque experimental");}
        if(attack!=null)attack.setEnabled(!busy&&eligible(true));
        if(returnHuman!=null)returnHuman.setEnabled(active);
    }
    private void confirmArm(){
        if(!eligible(false))return;
        if(current.optBoolean("armed",false)) {send("MOBILEDISARM",false);return;}
        new AlertDialog.Builder(this).setTitle("Armar ataque experimental?")
            .setMessage("A função nativa PlayAction pode derrubar o servidor, mesmo com proteção Lua. Utilize apenas em um clone com backup. Continuar?")
            .setNegativeButton("Cancelar",(d,w)->{})
            .setPositiveButton("Armar",(d,w)->send("MOBILEARM",false)).show();
    }
    private void send(String action,boolean isAttack){
        if(!eligible(isAttack) || busy) {setStatus("Comando bloqueado: sessão não confirmada.");return;}
        long now=System.currentTimeMillis();
        if(isAttack){
            int cd=Math.max(8,current.optInt("cooldown_seconds",8));
            if(now-lastAttackAt<cd*1000L){setStatus("Recarga local: aguarde antes de atacar novamente.");return;}
        }
        final String session=current.optString("session","");
        final int sequence=nextSequence;
        if(sequence>99999998){setStatus("Número de comando esgotado; reinicie o mod no clone.");return;}
        final String command=action+" "+sequence+" "+session;
        final String token=key;
        runNetwork("Enviando "+action+"…",()->{
            new GameGridFiles(token).writeCommand(command);
            ui.post(()->{
                nextSequence=sequence+1;
                getPreferences(MODE_PRIVATE).edit().putInt("local_seq",nextSequence).apply();
                if(isAttack)lastAttackAt=System.currentTimeMillis();
                setStatus("Arquivo enviado. Aguardando confirmação do mod; envio não prova golpe no Xbox.");
            });
        });
    }
    @Override protected void onResume(){super.onResume(); foreground=true;ui.removeCallbacks(poll);ui.postDelayed(poll,5000);}
    @Override protected void onPause(){foreground=false;ui.removeCallbacks(poll);super.onPause();}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
