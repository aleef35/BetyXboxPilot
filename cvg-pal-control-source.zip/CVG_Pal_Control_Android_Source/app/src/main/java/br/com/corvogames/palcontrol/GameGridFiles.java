package br.com.corvogames.palcontrol;

import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import android.util.Base64;

/** GameGrid file API transport. Verify paths/body against authenticated /openapi.json before production. */
public final class GameGridFiles {
    private static final String HOST = "https://wdcgamegrid.com/api/public/v1";
    public static final String SERVER = "00000052";
    private static final String PREFIX = "Pal/Binaries/Win64/Mods/CVGBossControl/";
    public static final String STATE_PATH = PREFIX + "cvg_mobile_status.json";
    public static final String REQUEST_PATH = PREFIX + "cvg_v06_request.txt";
    public static class Failure extends Exception {
        public final int status;
        Failure(int status, String message){ super(message); this.status=status; }
    }
    private final String key;
    public GameGridFiles(String key) throws Failure {
        if (key==null || !key.trim().matches("gsk_[A-Za-z0-9]{8}_[A-Za-z0-9_-]{43}"))
            throw new Failure(0,"Chave GameGrid inválida; nunca compartilhe no chat.");
        this.key=key.trim();
    }
    private static String encode(String s) throws Exception { return java.net.URLEncoder.encode(s, "UTF-8"); }
    private JSONObject request(String method,String route,JSONObject body) throws Exception {
        URL u=new URL(HOST+route);
        if (!"https".equals(u.getProtocol()) || !"wdcgamegrid.com".equals(u.getHost())) throw new Failure(0,"Destino HTTP inválido");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();
        try {
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod(method);
            c.setConnectTimeout(9000); c.setReadTimeout(10000);
            c.setRequestProperty("Authorization", "Bearer "+key);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Cache-Control", "no-store");
            if (body!=null){
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                try(OutputStream out=c.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            }
            int status=c.getResponseCode();
            String raw="";
            InputStream ins=status>=200 && status<300?c.getInputStream():c.getErrorStream();
            if(ins!=null){ try(InputStream i=ins;ByteArrayOutputStream b=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096]; int n;
                while((n=i.read(buf))!=-1){ if(b.size()+n>350000) throw new Failure(0,"Resposta grande demais");b.write(buf,0,n); }
                raw=b.toString("UTF-8");
            }}
            if(status<200 || status>=300) {
                String detail="";
                try { JSONObject e=new JSONObject(raw).optJSONObject("error"); if(e!=null) detail=e.optString("code",""); } catch(Exception ignored){}
                throw new Failure(status,"GameGrid HTTP "+status+(detail.isEmpty()?"":" ("+detail+")"));
            }
            try {return new JSONObject(raw);}catch(Exception e){return new JSONObject().put("raw",raw);}
        } finally {c.disconnect();}
    }
    public void checkKey() throws Exception { request("GET","/account/keys/current",null); }
    private static String unpack(JSONObject j) throws Exception {
        if(j.has("content")) return j.optString("content","");
        if(j.has("data")){
            Object data=j.opt("data");
            if(data instanceof JSONObject) return unpack((JSONObject)data);
            if(data instanceof String) {
                if("base64".equalsIgnoreCase(j.optString("encoding","")))
                    return new String(Base64.decode((String)data,Base64.DEFAULT), StandardCharsets.UTF_8);
                return (String)data;
            }
        }
        return j.optString("raw","");
    }
    public JSONObject getPalState() throws Exception {
        String route="/servers/"+SERVER+"/files/read?path="+encode(STATE_PATH);
        JSONObject obj=request("GET",route,null);
        String raw=unpack(obj);
        if(raw.isEmpty()) throw new Failure(0,"Arquivo de estado vazio. Mod ponte não instalado ou resposta desconhecida.");
        JSONObject state=new JSONObject(raw);
        if(state.optInt("schema",0)!=1) throw new Failure(0,"Formato de estado incompatível.");
        return state;
    }
    /** Only the fixed command-file path is writable by this client. No generic file manager. */
    public void writeCommand(String text) throws Exception {
        if(!text.matches("^MOBILE(ARM|DISARM|CHECK|ATTACK|RETURN) [0-9]{1,8} [0-9]{10,20}$"))
            throw new Failure(0,"Formato de comando rejeitado localmente.");
        JSONObject payload=new JSONObject().put("path",REQUEST_PATH).put("content",text+"\n");
        // API file-write route: pending live OpenAPI contract verification.
        // Do not silently send to another route or retry native attacks.
        request("POST","/servers/"+SERVER+"/files/write",payload);
    }
}
