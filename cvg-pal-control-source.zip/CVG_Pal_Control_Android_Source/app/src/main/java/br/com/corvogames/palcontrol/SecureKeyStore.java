package br.com.corvogames.palcontrol;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores only AES-GCM-encrypted API-key bytes in the app's private preferences.
 * The AES key is non-exportable and owned by Android Keystore. No API key is
 * embedded in the application, backed up, or saved as plain text.
 */
public final class SecureKeyStore {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS = "cvg_pal_control_api_key_aes_v1";
    private static final String PREFS = "cvg_pal_control_private_credentials";
    private static final String CIPHERTEXT = "credential_aes_gcm";
    private static final String REMEMBER_SETTING = "remember_requested";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";

    private SecureKeyStore() {}

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SecretKey secretKey(boolean create) throws Exception {
        KeyStore store = KeyStore.getInstance(KEYSTORE);
        store.load(null);
        java.security.Key key = store.getKey(ALIAS, null);
        if (key instanceof SecretKey) return (SecretKey) key;
        if (!create) return null;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    public static boolean isRememberEnabled(Context context) {
        return preferences(context).getBoolean(REMEMBER_SETTING, true);
    }

    public static boolean setRememberEnabled(Context context, boolean enabled) {
        return preferences(context).edit().putBoolean(REMEMBER_SETTING, enabled).commit();
    }

    /** Encrypts and persists only after API authentication succeeds. */
    public static void save(Context context, String apiKey) throws Exception {
        if (apiKey == null || !apiKey.matches("gsk_[A-Za-z0-9]{8}_[A-Za-z0-9_-]{43}"))
            throw new IllegalArgumentException("Formato inválido de chave.");
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey(true));
        byte[] ciphertext = cipher.doFinal(apiKey.getBytes(StandardCharsets.UTF_8));
        String content = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)
                + ":" + Base64.encodeToString(ciphertext, Base64.NO_WRAP);
        if (!preferences(context).edit().putString(CIPHERTEXT, content).commit())
            throw new IllegalStateException("Não foi possível salvar a chave no armazenamento privado.");
    }

    /** Restores the key on the same phone, but never writes it to logs or UI. */
    public static String load(Context context) throws Exception {
        String raw = preferences(context).getString(CIPHERTEXT, null);
        if (raw == null || raw.isEmpty()) return null;
        String[] pair = raw.split(":", -1);
        if (pair.length != 2) throw new IllegalStateException("Chave salva danificada.");
        byte[] iv = Base64.decode(pair[0], Base64.NO_WRAP);
        byte[] ciphertext = Base64.decode(pair[1], Base64.NO_WRAP);
        if (iv.length != 12 || ciphertext.length < 16)
            throw new IllegalStateException("Dados da chave salva inválidos.");
        SecretKey secret = secretKey(false);
        if (secret == null) throw new IllegalStateException("Chave de criptografia não está disponível.");
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, secret, new GCMParameterSpec(128, iv));
        String decoded = new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
        if (!decoded.matches("gsk_[A-Za-z0-9]{8}_[A-Za-z0-9_-]{43}"))
            throw new IllegalStateException("Chave salva inválida.");
        return decoded;
    }

    /** Erases the encrypted credential and its Keystore encryption key. */
    public static void clear(Context context) throws Exception {
        if (!preferences(context).edit().remove(CIPHERTEXT).commit())
            throw new IllegalStateException("Não foi possível apagar a credencial.");
        KeyStore store = KeyStore.getInstance(KEYSTORE);
        store.load(null);
        if (store.containsAlias(ALIAS)) store.deleteEntry(ALIAS);
    }
}
