# Bety Xbox Pilot 0.2

Protótipo Android para controlar o Xbox Remote Play no celular usando visão por IA e os controles de toque do app Xbox.

## O que já está implementado

- Captura da tela com `MediaProjection` mediante autorização do usuário.
- Serviço em primeiro plano compatível com Android 14+.
- Serviço de Acessibilidade com `dispatchGesture()` para taps e swipes.
- Restrição de comandos aos pacotes oficiais Xbox / Xbox beta.
- Botão flutuante de emergência `PARAR BETY`.
- Envio de captura JPEG para a OpenAI Responses API com entrada de imagem.
- Saída estruturada em JSON: `tap`, `swipe`, `wait` ou `stop`.
- Coordenadas normalizadas 0..1000 para funcionar em diferentes resoluções.
- Perfil inicial calibrado pela tela enviada do Aniimo, com posições aproximadas dos analógicos, direcional, A/B/X/Y, LT e RT.
- Confirmação visual obrigatória antes de reutilizar as posições calibradas, evitando toques incorretos se o layout mudar.
- Bloqueio por baixa confiança.
- Detecção simples de tela quase toda preta para evitar comandos às cegas.
- Modo somente sugestão, desmarcando "Executar os toques automaticamente".

## Requisitos

- Android 10 ou superior.
- App Xbox oficial instalado.
- Remote Play funcionando e controles de toque visíveis.
- Uma chave da OpenAI API com saldo. A assinatura do ChatGPT não substitui créditos da API.

## Compilar no Android Studio

1. Instale Android Studio atual.
2. Abra a pasta `BetyXboxPilot`.
3. Aguarde o Gradle Sync baixar dependências.
4. Se solicitado, instale Android SDK Platform 35.
5. `Build > Build APK(s)`.
6. O APK debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Usar

1. Abra `Bety Xbox Pilot`.
2. Toque em `Ativar controle por acessibilidade` e habilite o serviço.
3. Cole sua chave da OpenAI.
4. Escreva um objetivo curto, por exemplo: `No Aniimo, vá até o Lumin Amber marcado no mapa e colete-o.`
5. Toque em `Compartilhar tela e iniciar` e aceite a captura.
6. Abra o app Xbox e inicie Remote Play.
7. Deixe os controles de toque do Xbox visíveis.
8. O botão flutuante `PARAR BETY` interrompe a automação imediatamente.

## Limitações importantes

- Alguns fluxos de vídeo podem usar proteção de conteúdo e aparecer pretos em capturas Android. O app detecta quadro quase preto e pausa.
- O modelo recebe quadros discretos, não vídeo contínuo; portanto o projeto é adequado a navegação, menus e exploração, não a combate competitivo de baixa latência.
- A automação depende da posição dos controles virtuais visíveis. Mudanças de layout, orientação e UI podem reduzir a precisão.
- Serviços de Acessibilidade podem estar sujeitos a políticas da loja de aplicativos e devem ser usados de forma transparente e somente com controle do proprietário do aparelho.
- Automação em jogos pode contrariar regras específicas do jogo/serviço. Use apenas onde permitido.

## Privacidade

- A chave da OpenAI não é gravada em disco por este protótipo; ela fica em memória enquanto o serviço está ativo.
- Capturas são enviadas à API apenas durante a sessão ativa e somente quando o app Xbox está em primeiro plano.
- Evite exibir senhas, códigos de autenticação, dados de pagamento ou outras informações sensíveis durante o piloto automático.

## Build automático no GitHub

O projeto inclui `.github/workflows/android-debug-apk.yml`. Ao publicar a pasta em um repositório GitHub e executar a ação `Build Android Debug APK`, o GitHub gera `app-debug.apk` e disponibiliza o APK como artifact do workflow.
