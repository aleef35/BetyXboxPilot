package com.corvogames.betyxboxpilot

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class OpenAiVisionClient(
    private val apiKey: String,
    private val model: String
) {
    data class Result(val action: PilotAction?, val error: String? = null)

    fun decide(jpeg: ByteArray, goal: String): Result {
        val imageB64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val body = buildBody(imageB64, goal)
        val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20_000
            readTimeout = 45_000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        return try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = BufferedReader(InputStreamReader(stream)).use { it.readText() }
            if (code !in 200..299) {
                return Result(null, "OpenAI HTTP $code: ${friendlyApiError(raw)}")
            }
            val root = JSONObject(raw)
            val outputText = extractOutputText(root)
                ?: return Result(null, "A resposta da IA não trouxe uma ação.")
            val obj = JSONObject(outputText)
            Result(
                PilotAction(
                    action = obj.optString("action", "wait"),
                    x = obj.optInt("x", 500),
                    y = obj.optInt("y", 500),
                    x2 = obj.optInt("x2", 500),
                    y2 = obj.optInt("y2", 500),
                    durationMs = obj.optLong("duration_ms", 250L),
                    reason = obj.optString("reason", ""),
                    confidence = obj.optDouble("confidence", 0.0)
                )
            )
        } catch (t: Throwable) {
            Result(null, "Falha de rede/API: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            conn.disconnect()
        }
    }

    private fun buildBody(imageB64: String, goal: String): JSONObject {
        val developerText = """
            Você é o módulo visual de controle da Bety Xbox Pilot. A imagem é uma captura do Android durante Xbox Remote Play.
            Controle SOMENTE pelos controles de toque visíveis do Xbox. Nunca tente abrir configurações, contas, compras, chats ou outros apps.
            O objetivo atual é: $goal
            Escolha apenas UMA ação curta por quadro para permitir correção em malha fechada.
            Coordenadas x/y e x2/y2 são normalizadas de 0 a 1000 relativas à captura inteira.
            Para movimentar analógico virtual, use swipe começando no centro visual do analógico e terminando na direção desejada. Duração máxima 1200 ms.
            Para botões A/B/X/Y/menu/mapa, use tap no centro visual do botão.
            A captura de referência atual é vertical, com o vídeo do jogo no centro e os controles na faixa inferior. Use estes centros aproximados SOMENTE quando o controle continuar com o mesmo desenho: analógico esquerdo (152,679), direcional (253,725), analógico direito (747,726), Y (847,660), X (807,678), B (886,679), A (847,697), LT (65,660) e RT (949,660).
            Antes de usar um desses centros, confirme visualmente que o botão está naquele local. Se o layout mudar, localize o controle novamente pela imagem em vez de repetir coordenadas antigas.
            Para andar, faça swipe a partir do analógico esquerdo e mantenha o gesto entre 350 e 1200 ms. Para mover a câmera, faça swipe a partir do analógico direito. Não toque dentro da imagem do jogo quando a intenção for usar um botão do controle.
            Se a tela não for do Xbox Remote Play, os controles não estiverem visíveis, houver diálogo sensível, compra, login, senha, ou você estiver incerto, retorne wait.
            Se o objetivo tiver terminado, retorne stop.
        """.trimIndent()

        val developer = JSONObject()
            .put("role", "developer")
            .put("content", JSONArray().put(JSONObject().put("type", "input_text").put("text", developerText)))

        val userContent = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", "Observe a tela atual e escolha o próximo toque ou gesto."))
            .put(JSONObject().put("type", "input_image").put("image_url", "data:image/jpeg;base64,$imageB64").put("detail", "low"))

        val user = JSONObject().put("role", "user").put("content", userContent)

        val properties = JSONObject()
            .put("action", JSONObject().put("type", "string").put("enum", JSONArray(listOf("tap", "swipe", "wait", "stop"))))
            .put("x", JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 1000))
            .put("y", JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 1000))
            .put("x2", JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 1000))
            .put("y2", JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 1000))
            .put("duration_ms", JSONObject().put("type", "integer").put("minimum", 80).put("maximum", 1500))
            .put("reason", JSONObject().put("type", "string"))
            .put("confidence", JSONObject().put("type", "number").put("minimum", 0).put("maximum", 1))

        val schema = JSONObject()
            .put("type", "object")
            .put("additionalProperties", false)
            .put("properties", properties)
            .put("required", JSONArray(listOf("action", "x", "y", "x2", "y2", "duration_ms", "reason", "confidence")))

        val format = JSONObject()
            .put("type", "json_schema")
            .put("name", "bety_controller_action")
            .put("strict", true)
            .put("schema", schema)

        return JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(developer).put(user))
            .put("text", JSONObject().put("format", format))
            .put("max_output_tokens", 180)
    }

    private fun extractOutputText(root: JSONObject): String? {
        val output = root.optJSONArray("output") ?: return null
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") {
                    val text = part.optString("text", "")
                    if (text.isNotBlank()) return text
                }
            }
        }
        return null
    }

    private fun friendlyApiError(raw: String): String {
        return runCatching {
            val obj = JSONObject(raw)
            obj.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: raw.take(240)
    }
}
