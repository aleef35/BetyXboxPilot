package com.corvogames.betyxboxpilot

object PilotState {
    @Volatile var active: Boolean = false
    @Volatile var autoExecute: Boolean = true
    @Volatile var status: String = "Parado"
    @Volatile var lastReason: String = ""
    @Volatile var foregroundPackage: String = ""
    @Volatile var capturedWidth: Int = 0
    @Volatile var capturedHeight: Int = 0

    val allowedXboxPackages = setOf(
        "com.microsoft.xboxone.smartglass",
        "com.microsoft.xboxone.smartglass.beta"
    )

    fun isXboxForeground(): Boolean = foregroundPackage in allowedXboxPackages
}
