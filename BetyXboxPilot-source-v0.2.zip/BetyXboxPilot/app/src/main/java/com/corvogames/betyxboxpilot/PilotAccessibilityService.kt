package com.corvogames.betyxboxpilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class PilotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: PilotAccessibilityService? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var stopOverlay: Button? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg.isNotBlank()) PilotState.foregroundPackage = pkg
        refreshOverlay()
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun refreshOverlay() {
        mainHandler.post {
            if (PilotState.active && stopOverlay == null) addOverlay()
            if (!PilotState.active && stopOverlay != null) removeOverlay()
            stopOverlay?.text = if (PilotState.isXboxForeground()) "PARAR BETY" else "BETY PAUSADA"
        }
    }

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "PARAR BETY"
            textSize = 12f
            setOnClickListener {
                PilotState.active = false
                PilotState.status = "Parado pelo botão flutuante"
                stopService(android.content.Intent(this@PilotAccessibilityService, PilotControlService::class.java))
                refreshOverlay()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 120
        }
        wm.addView(button, params)
        stopOverlay = button
    }

    private fun removeOverlay() {
        val view = stopOverlay ?: return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        runCatching { wm.removeView(view) }
        stopOverlay = null
    }

    fun execute(action: PilotAction): Boolean {
        if (!PilotState.active || !PilotState.autoExecute) return false
        if (!PilotState.isXboxForeground()) {
            PilotState.status = "Pausada: o app Xbox não está em foco"
            return false
        }

        val dm = resources.displayMetrics
        val width = dm.widthPixels.coerceAtLeast(1)
        val height = dm.heightPixels.coerceAtLeast(1)
        fun pxX(n: Int) = (n.coerceIn(0, 1000) / 1000f) * width
        fun pxY(n: Int) = (n.coerceIn(0, 1000) / 1000f) * height

        return when (action.action.lowercase()) {
            "tap" -> {
                val path = Path().apply { moveTo(pxX(action.x), pxY(action.y)) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
                    .build()
                dispatchGesture(gesture, null, null)
            }
            "swipe" -> {
                val path = Path().apply {
                    moveTo(pxX(action.x), pxY(action.y))
                    lineTo(pxX(action.x2), pxY(action.y2))
                }
                val duration = action.durationMs.coerceIn(100L, 1500L)
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                    .build()
                dispatchGesture(gesture, null, null)
            }
            "stop" -> {
                PilotState.active = false
                PilotState.status = "A IA pediu parada"
                refreshOverlay()
                false
            }
            else -> false
        }
    }
}
