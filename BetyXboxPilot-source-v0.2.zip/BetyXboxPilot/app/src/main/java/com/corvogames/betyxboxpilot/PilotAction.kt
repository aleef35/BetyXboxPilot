package com.corvogames.betyxboxpilot

data class PilotAction(
    val action: String,
    val x: Int = 500,
    val y: Int = 500,
    val x2: Int = 500,
    val y2: Int = 500,
    val durationMs: Long = 250L,
    val reason: String = "",
    val confidence: Double = 0.0
)
