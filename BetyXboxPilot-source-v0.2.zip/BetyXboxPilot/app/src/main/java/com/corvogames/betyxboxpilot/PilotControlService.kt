package com.corvogames.betyxboxpilot

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class PilotControlService : Service() {

    companion object {
        const val ACTION_START = "com.corvogames.betyxboxpilot.START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_PROJECTION_DATA = "projection_data"
        const val EXTRA_API_KEY = "api_key"
        const val EXTRA_GOAL = "goal"
        const val EXTRA_MODEL = "model"
        const val EXTRA_AUTO_EXECUTE = "auto_execute"
        private const val CHANNEL_ID = "bety_pilot"
        private const val NOTIFICATION_ID = 355
    }

    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val deciding = AtomicBoolean(false)
    private var capture: ScreenCaptureEngine? = null
    private var client: OpenAiVisionClient? = null
    private var goal: String = ""
    private var projectionCallback: MediaProjection.Callback? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) return START_NOT_STICKY

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }
        val apiKey = intent.getStringExtra(EXTRA_API_KEY).orEmpty()
        goal = intent.getStringExtra(EXTRA_GOAL).orEmpty()
        val model = intent.getStringExtra(EXTRA_MODEL).orEmpty().ifBlank { "gpt-6-luna" }
        PilotState.autoExecute = intent.getBooleanExtra(EXTRA_AUTO_EXECUTE, true)

        if (resultCode == -1 || data == null || apiKey.isBlank()) {
            PilotState.status = "Falha: dados de inicialização ausentes"
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mgr.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                PilotState.status = "Captura de tela encerrada pelo Android"
                stopSelf()
            }
        }.also { projection.registerCallback(it, null) }

        capture?.stop()
        capture = ScreenCaptureEngine(this, projection).also { it.start() }
        client = OpenAiVisionClient(apiKey, model)
        PilotState.active = true
        PilotState.status = "Ativa. Abra o Remote Play do Xbox."
        PilotAccessibilityService.instance?.refreshOverlay()

        executor.scheduleWithFixedDelay({ tick() }, 1200, 1700, TimeUnit.MILLISECONDS)
        return START_NOT_STICKY
    }

    private fun tick() {
        if (!PilotState.active || deciding.getAndSet(true)) return
        try {
            if (!PilotState.isXboxForeground()) {
                PilotState.status = "Pausada: aguardando o app Xbox em primeiro plano"
                return
            }

            val engine = capture ?: return
            if (engine.lastFrameMostlyBlack) {
                PilotState.status = "Pausada: a captura parece preta/protegida"
                PilotState.lastReason = "O Xbox pode estar bloqueando captura por MediaProjection."
                return
            }

            val frame = engine.latestJpeg()
            if (frame == null) {
                PilotState.status = "Aguardando primeiro quadro..."
                return
            }

            PilotState.status = "Bety analisando a tela..."
            val result = client?.decide(frame, goal) ?: return
            if (result.error != null) {
                PilotState.status = result.error
                return
            }

            val action = result.action ?: return
            PilotState.lastReason = action.reason

            if (action.confidence < 0.55 && action.action !in listOf("wait", "stop")) {
                PilotState.status = "Aguardando: baixa confiança (${String.format("%.0f", action.confidence * 100)}%)"
                return
            }

            when (action.action.lowercase()) {
                "wait" -> PilotState.status = "Aguardando: ${action.reason}"
                "stop" -> {
                    PilotState.status = "Objetivo concluído / parada solicitada"
                    PilotState.active = false
                    PilotAccessibilityService.instance?.refreshOverlay()
                    stopSelf()
                }
                else -> {
                    if (!PilotState.autoExecute) {
                        PilotState.status = "Sugestão: ${action.action} (${action.x},${action.y})"
                    } else {
                        val ok = PilotAccessibilityService.instance?.execute(action) == true
                        PilotState.status = if (ok) "Executado: ${action.action}" else "Ação não executada"
                    }
                }
            }
        } finally {
            deciding.set(false)
        }
    }

    private fun startAsForeground() {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bety)
            .setContentTitle("Bety Xbox Pilot")
            .setContentText("Capturando a tela para pilotar o Remote Play")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Bety Pilot", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        PilotState.active = false
        PilotAccessibilityService.instance?.refreshOverlay()
        capture?.stop()
        capture = null
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
