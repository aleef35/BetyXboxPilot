package com.corvogames.betyxboxpilot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var edtApiKey: EditText
    private lateinit var edtGoal: EditText
    private lateinit var edtModel: EditText
    private lateinit var chkAuto: CheckBox

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startPilot(result.resultCode, result.data!!)
        } else {
            toast("Compartilhamento de tela cancelado.")
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtStatus)
        edtApiKey = findViewById(R.id.edtApiKey)
        edtGoal = findViewById(R.id.edtGoal)
        edtModel = findViewById(R.id.edtModel)
        chkAuto = findViewById(R.id.chkAuto)

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!isAccessibilityServiceEnabled()) {
                toast("Primeiro ative 'Bety Xbox Pilot' em Acessibilidade.")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }

            val key = edtApiKey.text.toString().trim()
            if (key.isBlank()) {
                edtApiKey.error = "Cole sua chave da OpenAI"
                return@setOnClickListener
            }

            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }

            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btnOpenXbox).setOnClickListener {
            val intent = packageManager.getLaunchIntentForPackage("com.microsoft.xboxone.smartglass")
            if (intent != null) startActivity(intent) else toast("App Xbox não encontrado.")
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, PilotControlService::class.java))
            PilotState.active = false
            PilotState.status = "Parado pelo usuário"
            PilotAccessibilityService.instance?.refreshOverlay()
            refreshStatus()
        }

        txtStatus.post(statusTicker)
    }

    private fun startPilot(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, PilotControlService::class.java).apply {
            action = PilotControlService.ACTION_START
            putExtra(PilotControlService.EXTRA_RESULT_CODE, resultCode)
            putExtra(PilotControlService.EXTRA_PROJECTION_DATA, data)
            putExtra(PilotControlService.EXTRA_API_KEY, edtApiKey.text.toString().trim())
            putExtra(PilotControlService.EXTRA_GOAL, edtGoal.text.toString().trim())
            putExtra(PilotControlService.EXTRA_MODEL, edtModel.text.toString().trim().ifBlank { "gpt-6-luna" })
            putExtra(PilotControlService.EXTRA_AUTO_EXECUTE, chkAuto.isChecked)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        PilotState.status = "Iniciando captura..."
        toast("Bety iniciada. Agora abra o Xbox Remote Play.")
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${PilotAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            refreshStatus()
            txtStatus.postDelayed(this, 500)
        }
    }

    private fun refreshStatus() {
        val pkg = PilotState.foregroundPackage.ifBlank { "nenhum" }
        val reason = PilotState.lastReason.takeIf { it.isNotBlank() }?.let { "\nÚltima decisão: $it" } ?: ""
        txtStatus.text = "Status: ${PilotState.status}\nTela em foco: $pkg$reason"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        txtStatus.removeCallbacks(statusTicker)
        super.onDestroy()
    }
}
