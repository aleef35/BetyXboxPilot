package com.corvogames.betyxboxpilot

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicReference

class ScreenCaptureEngine(
    private val context: Context,
    private val projection: MediaProjection
) {
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val latest = AtomicReference<ByteArray?>(null)
    @Volatile var lastFrameMostlyBlack: Boolean = false
        private set

    fun start() {
        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        PilotState.capturedWidth = width
        PilotState.capturedHeight = height

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { imageReader ->
            imageReader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val paddedWidth = width + rowPadding / pixelStride
                    val bitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                    bitmap.recycle()

                    val sample = downscale(cropped, 768)
                    cropped.recycle()
                    lastFrameMostlyBlack = isMostlyBlack(sample)
                    if (!lastFrameMostlyBlack) {
                        val out = ByteArrayOutputStream()
                        sample.compress(Bitmap.CompressFormat.JPEG, 62, out)
                        latest.set(out.toByteArray())
                    }
                    sample.recycle()
                } catch (_: Throwable) {
                } finally {
                    image.close()
                }
            }, null)
        }

        virtualDisplay = projection.createVirtualDisplay(
            "BetyXboxPilotCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            null,
            null
        )
    }

    fun latestJpeg(): ByteArray? = latest.get()

    private fun downscale(src: Bitmap, maxSide: Int): Bitmap {
        val biggest = maxOf(src.width, src.height)
        if (biggest <= maxSide) return src.copy(src.config ?: Bitmap.Config.ARGB_8888, false)
        val scale = maxSide.toFloat() / biggest
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }

    private fun isMostlyBlack(bitmap: Bitmap): Boolean {
        val stepX = (bitmap.width / 12).coerceAtLeast(1)
        val stepY = (bitmap.height / 12).coerceAtLeast(1)
        var dark = 0
        var total = 0
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                val lum = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
                if (lum < 7) dark++
                total++
                x += stepX
            }
            y += stepY
        }
        return total > 0 && dark.toDouble() / total > 0.94
    }

    fun stop() {
        runCatching { virtualDisplay?.release() }
        runCatching { reader?.close() }
        runCatching { projection.stop() }
        virtualDisplay = null
        reader = null
        latest.set(null)
    }
}
